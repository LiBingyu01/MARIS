#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MARIS qualitative visualization tool.

This script is intentionally independent from ``demo/predictor.py`` because the
original predictor mixes COCO/ADE20K/LVIS metadata.  For MARIS checkpoints we
must build the classifier and labels from WaterOVS metadata, otherwise category
indices and displayed names can be inconsistent.

Run this script from the MARIS repository root.
"""

from __future__ import annotations

import argparse
import colorsys
import glob
import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import cv2
import numpy as np
import torch

# Make ``import maris`` work when the script is launched as demo/visualize_maris.py.
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from detectron2.config import get_cfg
from detectron2.data import DatasetCatalog, MetadataCatalog
from detectron2.engine.defaults import DefaultPredictor
from detectron2.projects.deeplab import add_deeplab_config
from detectron2.structures import Instances
from detectron2.utils.logger import setup_logger
from detectron2.utils.visualizer import ColorMode, Visualizer

from maris import add_maskformer2_config, add_maris_config
from maris.data.datasets import openseg_classes

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Visualize MARIS open-vocabulary instance segmentation predictions."
    )
    parser.add_argument(
        "--config-file",
        required=True,
        help="MARIS YAML config, e.g. configs/convnext_base_waterovs_id.yaml",
    )
    parser.add_argument("--weights", required=True, help="Path to the released MARIS .pth checkpoint")
    parser.add_argument(
        "--input",
        nargs="+",
        required=True,
        help="Image path(s), directory/directories, or glob pattern(s)",
    )
    parser.add_argument("--output", required=True, help="Directory used to save visualizations")
    parser.add_argument(
        "--category-set",
        choices=("val", "train", "all", "custom"),
        default="val",
        help=(
            "val: official 115-class WaterOVS validation vocabulary; "
            "train: 84 seen classes; all: union of train and val (158 classes); "
            "custom: one class per line from --class-file"
        ),
    )
    parser.add_argument(
        "--class-file",
        default=None,
        help="UTF-8 text file with one custom open-vocabulary class per line",
    )
    parser.add_argument("--score-threshold", type=float, default=0.35)
    parser.add_argument("--min-mask-area", type=int, default=64, help="Minimum mask area in pixels")
    parser.add_argument("--max-instances", type=int, default=30)
    parser.add_argument(
        "--view-mode",
        choices=("overlay", "side-by-side", "mask-only"),
        default="side-by-side",
    )
    parser.add_argument("--alpha", type=float, default=0.58, help="Mask opacity")
    parser.add_argument("--save-json", action="store_true", help="Save per-image predictions as JSON")
    parser.add_argument("--save-masks", action="store_true", help="Save each retained binary instance mask")
    parser.add_argument("--recursive", action="store_true", help="Search directories recursively")
    parser.add_argument("--device", default="cuda", help="cuda, cuda:0, or cpu")
    parser.add_argument(
        "--topk-per-image",
        type=int,
        default=100,
        help="Number of query/class candidates produced before score filtering",
    )

    # These defaults mirror the released training command in KEY_START_id.sh.
    parser.add_argument("--gpem-fusion", choices=("add", "mlp", "alpha_fusion"), default="alpha_fusion")
    parser.add_argument("--depth-model", choices=("vits", "vitb", "vitl"), default="vitb")
    parser.add_argument("--spim-select", choices=("mixed", "weighted", "noselect"), default="mixed")
    parser.add_argument("--spim-topn", type=int, default=20)
    parser.add_argument(
        "--clip-weights",
        default=None,
        help="Optional override for MODEL.MARIS.CLIP_PRETRAINED_WEIGHTS",
    )
    parser.add_argument(
        "--opts",
        default=[],
        nargs=argparse.REMAINDER,
        help="Additional Detectron2 config overrides: KEY VALUE ...",
    )
    return parser.parse_args()


def validate_paths(args: argparse.Namespace) -> None:
    config_path = Path(args.config_file)
    weights_path = Path(args.weights)
    if not config_path.is_file():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    if not weights_path.is_file():
        raise FileNotFoundError(f"MARIS checkpoint not found: {weights_path}")
    if args.category_set == "custom":
        if not args.class_file:
            raise ValueError("--class-file is required when --category-set custom is used")
        if not Path(args.class_file).is_file():
            raise FileNotFoundError(f"Custom class file not found: {args.class_file}")
    if not 0.0 <= args.score_threshold <= 1.0:
        raise ValueError("--score-threshold must be within [0, 1]")
    if not 0.0 <= args.alpha <= 1.0:
        raise ValueError("--alpha must be within [0, 1]")
    if args.max_instances <= 0:
        raise ValueError("--max-instances must be positive")


def setup_cfg(args: argparse.Namespace):
    cfg = get_cfg()
    add_deeplab_config(cfg)
    add_maskformer2_config(cfg)
    add_maris_config(cfg)
    cfg.merge_from_file(args.config_file)
    cfg.merge_from_list(args.opts)

    cfg.defrost()
    cfg.MODEL.WEIGHTS = str(Path(args.weights).resolve())
    cfg.MODEL.DEVICE = args.device
    cfg.TEST.DETECTIONS_PER_IMAGE = args.topk_per_image
    cfg.MODEL.GPEM.FUSION = args.gpem_fusion
    cfg.MODEL.GPEM.DEPTHANYTHING_MODEL = args.depth_model
    cfg.MODEL.SPIM.SELECT_TYPE = args.spim_select
    cfg.MODEL.SPIM.TOPN = args.spim_topn
    if args.clip_weights:
        cfg.MODEL.MARIS.CLIP_PRETRAINED_WEIGHTS = str(Path(args.clip_weights).resolve())
    cfg.freeze()
    return cfg


def deterministic_color(index: int, total: int) -> List[int]:
    """Return a stable RGB color for a custom class."""
    hue = (index / max(total, 1) + 0.618033988749895) % 1.0
    red, green, blue = colorsys.hsv_to_rgb(hue, 0.68, 0.95)
    return [int(red * 255), int(green * 255), int(blue * 255)]


def load_custom_categories(class_file: str) -> List[Dict]:
    names: List[str] = []
    seen_names = set()
    with open(class_file, "r", encoding="utf-8-sig") as file:
        for raw_line in file:
            name = raw_line.strip()
            if not name or name.startswith("#"):
                continue
            lowered = name.casefold()
            if lowered in seen_names:
                continue
            seen_names.add(lowered)
            names.append(name)
    if not names:
        raise ValueError(f"No valid classes were found in {class_file}")
    return [
        {
            "id": index + 1,
            "name": name,
            "color": deterministic_color(index, len(names)),
            "isthing": 1,
        }
        for index, name in enumerate(names)
    ]


def get_categories(args: argparse.Namespace) -> Tuple[List[Dict], set]:
    train_categories = openseg_classes.get_waterovs_categories_with_prompt_eng_train()
    val_categories = openseg_classes.get_waterovs_categories_with_prompt_eng_val()
    seen_dataset_ids = {category["id"] for category in train_categories}

    if args.category_set == "train":
        categories = train_categories
    elif args.category_set == "val":
        # Preserve the official validation category order exactly.
        categories = val_categories
    elif args.category_set == "all":
        merged = {category["id"]: dict(category) for category in train_categories}
        merged.update({category["id"]: dict(category) for category in val_categories})
        categories = [merged[dataset_id] for dataset_id in sorted(merged)]
    else:
        categories = load_custom_categories(args.class_file)
        seen_dataset_ids = set()

    return categories, seen_dataset_ids


def register_visualization_metadata(categories: Sequence[Dict], name_suffix: str):
    metadata_name = f"maris_visualization_{name_suffix}"
    if metadata_name not in DatasetCatalog.list():
        DatasetCatalog.register(metadata_name, lambda: [])

    classes = [category["name"] for category in categories]
    colors = [category.get("color", deterministic_color(i, len(categories))) for i, category in enumerate(categories)]
    id_mapping = {category["id"]: index for index, category in enumerate(categories)}

    return MetadataCatalog.get(metadata_name).set(
        thing_classes=classes,
        thing_colors=colors,
        thing_dataset_id_to_contiguous_id=id_mapping,
        evaluator_type="coco",
    )


def expand_inputs(inputs: Sequence[str], recursive: bool) -> List[Path]:
    paths: List[Path] = []
    for item in inputs:
        expanded_item = os.path.expandvars(os.path.expanduser(item))
        candidate = Path(expanded_item)
        if candidate.is_file():
            if candidate.suffix.lower() in IMAGE_EXTENSIONS:
                paths.append(candidate.resolve())
            continue
        if candidate.is_dir():
            iterator: Iterable[Path] = candidate.rglob("*") if recursive else candidate.glob("*")
            paths.extend(path.resolve() for path in iterator if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS)
            continue
        for matched in glob.glob(expanded_item, recursive=recursive):
            matched_path = Path(matched)
            if matched_path.is_file() and matched_path.suffix.lower() in IMAGE_EXTENSIONS:
                paths.append(matched_path.resolve())

    unique_paths = sorted(set(paths), key=lambda path: str(path).lower())
    if not unique_paths:
        raise FileNotFoundError("No input images were found")
    return unique_paths


def read_image_unicode(path: Path) -> np.ndarray:
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"OpenCV failed to read image: {path}")
    return image


def write_image_unicode(path: Path, image_bgr: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    extension = path.suffix if path.suffix else ".jpg"
    success, encoded = cv2.imencode(extension, image_bgr)
    if not success:
        raise ValueError(f"OpenCV failed to encode image: {path}")
    encoded.tofile(str(path))


def filter_instances(instances: Instances, score_threshold: float, min_mask_area: int, max_instances: int) -> Instances:
    instances = instances.to("cpu")
    if len(instances) == 0:
        return instances

    scores = instances.scores
    masks = instances.pred_masks.bool()
    areas = masks.flatten(1).sum(dim=1)
    keep = (scores >= score_threshold) & (areas >= min_mask_area)
    instances = instances[keep]
    if len(instances) == 0:
        return instances

    order = torch.argsort(instances.scores, descending=True)[:max_instances]
    return instances[order]


def mask_to_bbox(mask: np.ndarray) -> List[int]:
    ys, xs = np.where(mask)
    if len(xs) == 0:
        return [0, 0, 0, 0]
    return [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]


def create_labels_and_colors(
    instances: Instances,
    categories: Sequence[Dict],
    seen_dataset_ids: set,
    category_set: str,
) -> Tuple[List[str], List[List[float]]]:
    labels: List[str] = []
    colors: List[List[float]] = []

    for contiguous_id, score in zip(instances.pred_classes.tolist(), instances.scores.tolist()):
        if contiguous_id < 0 or contiguous_id >= len(categories):
            class_name = f"class_{contiguous_id}"
            dataset_id = None
            rgb = deterministic_color(contiguous_id, max(len(categories), 1))
        else:
            category = categories[contiguous_id]
            class_name = category["name"]
            dataset_id = category["id"]
            rgb = category.get("color", deterministic_color(contiguous_id, len(categories)))

        if category_set in {"val", "all"} and dataset_id is not None:
            split_tag = "S" if dataset_id in seen_dataset_ids else "U"
            label = f"{class_name} [{split_tag}] {score:.2f}"
        else:
            label = f"{class_name} {score:.2f}"

        labels.append(label)
        colors.append([channel / 255.0 for channel in rgb])

    return labels, colors


def add_headers(left_rgb: np.ndarray, right_rgb: np.ndarray) -> np.ndarray:
    header_height = max(34, int(round(left_rgb.shape[0] * 0.045)))
    font_scale = max(0.55, left_rgb.shape[1] / 1600.0)
    thickness = max(1, int(round(font_scale * 1.5)))

    left_header = np.full((header_height, left_rgb.shape[1], 3), 245, dtype=np.uint8)
    right_header = np.full((header_height, right_rgb.shape[1], 3), 245, dtype=np.uint8)
    cv2.putText(left_header, "Input image", (12, int(header_height * 0.72)), cv2.FONT_HERSHEY_SIMPLEX, font_scale, (30, 30, 30), thickness, cv2.LINE_AA)
    cv2.putText(right_header, "MARIS prediction", (12, int(header_height * 0.72)), cv2.FONT_HERSHEY_SIMPLEX, font_scale, (30, 30, 30), thickness, cv2.LINE_AA)

    left_panel = np.concatenate([left_header, left_rgb], axis=0)
    right_panel = np.concatenate([right_header, right_rgb], axis=0)
    divider = np.full((left_panel.shape[0], 4, 3), 255, dtype=np.uint8)
    return np.concatenate([left_panel, divider, right_panel], axis=1)


def render_instances(
    image_bgr: np.ndarray,
    instances: Instances,
    labels: Sequence[str],
    colors: Sequence[Sequence[float]],
    alpha: float,
    view_mode: str,
) -> np.ndarray:
    image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    base_rgb = np.zeros_like(image_rgb) if view_mode == "mask-only" else image_rgb
    visualizer = Visualizer(base_rgb, metadata=None, instance_mode=ColorMode.IMAGE, scale=1.0)

    if len(instances) > 0:
        output = visualizer.overlay_instances(
            labels=list(labels),
            masks=instances.pred_masks.numpy(),
            assigned_colors=list(colors),
            alpha=1.0 if view_mode == "mask-only" else alpha,
        )
        prediction_rgb = output.get_image()
    else:
        prediction_rgb = base_rgb.copy()
        cv2.putText(
            prediction_rgb,
            "No prediction above threshold",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            max(0.6, image_rgb.shape[1] / 1400.0),
            (255, 255, 255) if view_mode == "mask-only" else (20, 20, 20),
            2,
            cv2.LINE_AA,
        )

    if view_mode == "side-by-side":
        result_rgb = add_headers(image_rgb, prediction_rgb)
    else:
        result_rgb = prediction_rgb
    return cv2.cvtColor(result_rgb, cv2.COLOR_RGB2BGR)


def build_prediction_records(
    instances: Instances,
    categories: Sequence[Dict],
    seen_dataset_ids: set,
    category_set: str,
    mask_directory: Path | None,
) -> List[Dict]:
    records: List[Dict] = []
    for index in range(len(instances)):
        contiguous_id = int(instances.pred_classes[index])
        score = float(instances.scores[index])
        mask = instances.pred_masks[index].numpy().astype(bool)
        category = categories[contiguous_id] if 0 <= contiguous_id < len(categories) else None
        dataset_id = category["id"] if category else None
        class_name = category["name"] if category else f"class_{contiguous_id}"
        split = None
        if category_set in {"val", "all"} and dataset_id is not None:
            split = "seen" if dataset_id in seen_dataset_ids else "unseen"

        mask_path = None
        if mask_directory is not None:
            mask_directory.mkdir(parents=True, exist_ok=True)
            safe_name = "".join(character if character.isalnum() or character in "-_" else "_" for character in class_name)
            filename = f"{index:03d}_{safe_name}_{score:.3f}.png"
            full_mask_path = mask_directory / filename
            write_image_unicode(full_mask_path, (mask.astype(np.uint8) * 255))
            mask_path = str(full_mask_path.name)

        records.append(
            {
                "instance_index": index,
                "contiguous_class_id": contiguous_id,
                "dataset_class_id": dataset_id,
                "class_name": class_name,
                "split": split,
                "score": round(score, 6),
                "mask_area": int(mask.sum()),
                "bbox_xyxy": mask_to_bbox(mask),
                "mask_file": mask_path,
            }
        )
    return records


def output_stem(path: Path) -> str:
    # A short digest avoids collisions when different folders contain the same filename.
    digest = hashlib.sha1(str(path).encode("utf-8")).hexdigest()[:8]
    return f"{path.stem}_{digest}"


def main() -> None:
    args = parse_args()
    validate_paths(args)
    logger = setup_logger(name="maris.visualization")

    # Existing MARIS modules use repository-relative pretrained paths.
    os.chdir(REPO_ROOT)

    categories, seen_dataset_ids = get_categories(args)
    metadata = register_visualization_metadata(categories, args.category_set)
    cfg = setup_cfg(args)

    logger.info("Building MARIS predictor...")
    predictor = DefaultPredictor(cfg)
    if not hasattr(predictor.model, "set_metadata"):
        raise AttributeError("The loaded model does not expose MARIS.set_metadata(metadata)")
    predictor.model.set_metadata(metadata)

    input_paths = expand_inputs(args.input, args.recursive)
    output_root = Path(args.output).resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    logger.info(
        "Vocabulary: %s (%d classes); inputs: %d; threshold: %.3f",
        args.category_set,
        len(categories),
        len(input_paths),
        args.score_threshold,
    )
    if args.category_set == "val":
        logger.info("Official val vocabulary contains 41 seen and 74 unseen classes.")

    manifest: List[Dict] = []
    for image_index, image_path in enumerate(input_paths, start=1):
        start_time = time.perf_counter()
        image_bgr = read_image_unicode(image_path)
        predictions = predictor(image_bgr)
        instances = predictions.get("instances")
        if instances is None:
            raise KeyError("MARIS output does not contain 'instances'. Check MODEL.MASK_FORMER.TEST.INSTANCE_ON")

        instances = filter_instances(
            instances,
            score_threshold=args.score_threshold,
            min_mask_area=args.min_mask_area,
            max_instances=args.max_instances,
        )
        labels, colors = create_labels_and_colors(
            instances,
            categories=categories,
            seen_dataset_ids=seen_dataset_ids,
            category_set=args.category_set,
        )
        visualization = render_instances(
            image_bgr,
            instances,
            labels=labels,
            colors=colors,
            alpha=args.alpha,
            view_mode=args.view_mode,
        )

        stem = output_stem(image_path)
        visualization_path = output_root / f"{stem}_vis.jpg"
        write_image_unicode(visualization_path, visualization)

        mask_directory = output_root / f"{stem}_masks" if args.save_masks else None
        records = build_prediction_records(
            instances,
            categories=categories,
            seen_dataset_ids=seen_dataset_ids,
            category_set=args.category_set,
            mask_directory=mask_directory,
        )

        elapsed = time.perf_counter() - start_time
        image_result = {
            "input_image": str(image_path),
            "visualization": str(visualization_path),
            "width": int(image_bgr.shape[1]),
            "height": int(image_bgr.shape[0]),
            "elapsed_seconds": round(elapsed, 4),
            "num_retained_instances": len(records),
            "predictions": records,
        }
        manifest.append(image_result)

        if args.save_json:
            with open(output_root / f"{stem}_predictions.json", "w", encoding="utf-8") as file:
                json.dump(image_result, file, ensure_ascii=False, indent=2)

        logger.info(
            "[%d/%d] %s -> %s | %d instances | %.2fs",
            image_index,
            len(input_paths),
            image_path.name,
            visualization_path.name,
            len(records),
            elapsed,
        )

    with open(output_root / "manifest.json", "w", encoding="utf-8") as file:
        json.dump(
            {
                "config_file": str(Path(args.config_file).resolve()),
                "weights": str(Path(args.weights).resolve()),
                "category_set": args.category_set,
                "num_classes": len(categories),
                "score_threshold": args.score_threshold,
                "results": manifest,
            },
            file,
            ensure_ascii=False,
            indent=2,
        )

    logger.info("Finished. Results were saved to %s", output_root)


if __name__ == "__main__":
    main()
