@echo off
setlocal

python demo\visualize_maris.py ^
  --config-file configs\convnext_base_waterovs_id.yaml ^
  --weights weights\maris_convnext_base_id.pth ^
  --input examples\underwater.jpg ^
  --output visualizations\official_val ^
  --category-set val ^
  --score-threshold 0.35 ^
  --view-mode side-by-side ^
  --save-json ^
  --save-masks

endlocal
