# Visualizing released MARIS checkpoints

The original `demo/demo.py` inherits a generic FC-CLIP visualization pipeline and mixes COCO, ADE20K, and LVIS metadata. For released MARIS checkpoints, use `demo/visualize_maris.py`; it builds the text classifier and displayed labels from WaterOVS categories and applies a real post-inference score threshold.

## 1. Required files

Run commands from the MARIS repository root. A typical layout is:

```text
MARIS-main/
├── configs/
├── demo/visualize_maris.py
├── pretrained/
│   ├── convnext_b.bin
│   └── depth_anything_v2_vitb.pth
├── weights/
│   └── maris_convnext_base_id.pth
└── examples/
    └── underwater.jpg
```

The model is constructed before the MARIS checkpoint is restored, so the matching frozen ConvNeXt-CLIP and DepthAnything-V2 files must still exist under `pretrained/`.

## 2. Official WaterOVS validation visualization

The official validation vocabulary contains 115 classes: 41 overlap with training categories and 74 are unseen. Labels ending in `[S]` and `[U]` indicate seen and unseen classes.

```bash
python demo/visualize_maris.py \
  --config-file configs/convnext_base_waterovs_id.yaml \
  --weights weights/maris_convnext_base_id.pth \
  --input examples/underwater.jpg \
  --output visualizations/official_val \
  --category-set val \
  --score-threshold 0.35 \
  --view-mode side-by-side \
  --save-json \
  --save-masks
```

The defaults match the released training command in `KEY_START_id.sh`:

```text
MODEL.GPEM.FUSION              alpha_fusion
MODEL.GPEM.DEPTHANYTHING_MODEL vitb
MODEL.SPIM.SELECT_TYPE         mixed
MODEL.SPIM.TOPN                20
```

Use the same architecture/configuration as the checkpoint. For a ConvNeXt-L checkpoint, switch to `configs/convnext_large_waterovs_id.yaml` and provide `pretrained/convnext_l.bin`.

## 3. Batch visualization

```bash
python demo/visualize_maris.py \
  --config-file configs/convnext_base_waterovs_id.yaml \
  --weights weights/maris_convnext_base_id.pth \
  --input datasets/WaterOVS/val \
  --output visualizations/waterovs_val \
  --recursive \
  --category-set val \
  --score-threshold 0.35
```

Each image produces a `*_vis.jpg`. A global `manifest.json` records runtime, retained instances, class names, scores, mask areas, and bounding boxes.

## 4. Full 158-class vocabulary

The union of the 84 training categories and 115 validation categories contains 158 unique classes:

```bash
python demo/visualize_maris.py \
  --config-file configs/convnext_base_waterovs_id.yaml \
  --weights weights/maris_convnext_base_id.pth \
  --input examples/*.jpg \
  --output visualizations/all_158 \
  --category-set all \
  --score-threshold 0.35
```

Use `val` for benchmark-aligned figures and `all` for an exploratory open-vocabulary showcase.

## 5. Custom open-vocabulary prompts

Create `custom_classes.txt`:

```text
whale shark
sea turtle
underwater robot
plastic bottle
shipwreck
```

Then run:

```bash
python demo/visualize_maris.py \
  --config-file configs/convnext_base_waterovs_id.yaml \
  --weights weights/maris_convnext_base_id.pth \
  --input examples/underwater.jpg \
  --output visualizations/custom \
  --category-set custom \
  --class-file custom_classes.txt \
  --score-threshold 0.25
```

Custom-vocabulary results are useful for demos, but they are not equivalent to official WaterOVS evaluation.

## 6. Useful options

```text
--view-mode overlay        Save the mask overlay only
--view-mode side-by-side   Save input and prediction together
--view-mode mask-only      Draw masks on a black background
--score-threshold 0.35     Remove low-confidence predictions
--min-mask-area 64         Remove tiny masks
--max-instances 30         Limit visual clutter
--save-json                Save structured prediction records
--save-masks               Save one binary PNG per instance
--device cuda:0            Select a GPU
```

A practical threshold sweep for project-page examples is `0.25`, `0.35`, and `0.50`. Do not select a threshold separately for every image; choose one threshold on a small development subset and keep it fixed for the final qualitative comparison.

## 7. Recommended figures

For a paper or project page, prepare three groups:

1. **Seen/unseen qualitative results:** use the official `val` vocabulary and retain `[S]/[U]` tags.
2. **Degradation robustness:** include color attenuation, turbidity, low illumination, occlusion, and small objects.
3. **Open-vocabulary showcase:** use a fixed custom class list and show categories outside the WaterOVS benchmark.

For method analysis, compare `GPEM.ENABLED True/False`, the trained SAIM/SPIM setting, and the final model while keeping checkpoint compatibility and all visualization thresholds fixed.
